1) All source code is in the src folder in packages

2) After compiling the source code, "Run Server.bat" should be run before "Run Client.bat" so that the client has a server to connect to

3) The client will try to connect to localhost by default, to change the IP address it attempts to connect to, edit the client.txt file and replace localhost:4321 with <desired ip>:4321
