package troublegame.server;

public enum Color {
	
	RED,
	GREEN,
	YELLOW,
	BLUE,
	RANDOM;
	
}
